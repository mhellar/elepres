<pre>
<?php
// modified from eim3.php
//
// modified for better "No_Email" = 1
// plus adds default $no_email=1
	
// TODO: Revise to ngv.vic.gov.au
header("Access-Control-Allow-Origin: *");
header("Access-Control-Expose-Headers: View-URL");

// defaults type
$type = 'unknown';
$name = 'National Gallery of Victoria';
$testing = '';
$signup = '';
$booth_no = '';
$booth_name = '';
$no_email = 1;

// log for connection testing, set FALSE for production
$log_post_vars = FALSE;

(isset($_POST['Name']) && $name = $_POST['Name']);
(isset($_POST['Type']) && $type = $_POST['Type']);
(isset($_POST['Title']) && $title = $_POST['Title']);
(isset($_POST['Creator']) && $creator = $_POST['Creator']);

// if No_Email exists and ="0", override default and make it 0
//if (isset($_POST['No_Email'])) { $no_email = ($_POST['No_Email'] == "0"	? 0 : 1); }



// project-specific code
if (file_exists('./'.$type.((isset($_GET['testing']) && $_GET['testing']==1) ? '_testing' :'').'.inc.php')){
	include('./'.$type.((isset($_GET['testing']) && $_GET['testing']==1) ? '_testing' :'').'.inc.php');
}


// prep data for logging
$log_content_id = (isset($log_content_id) ? $log_content_id : '');
//$extsignup = (isset($_POST['ext_signup']) ? htmlspecialchars($_POST['ext_signup'], ENT_QUOTES) : '');
$booth_name = (isset($_POST['boothname']) ? htmlspecialchars($_POST['boothname'], ENT_QUOTES) : '');
$booth_no = (isset($_POST['boothno']) ? htmlspecialchars($_POST['boothno'], ENT_QUOTES) : '');


//logging for testing POST variables
if ($log_post_vars===TRUE) {

	//A PHP array containing the data that we want to log.
	$dataToLog = array(
		date("Y-m-d H:i:s"), //Date and time
		$_SERVER['REMOTE_ADDR'], //IP address
		"Type=$type",
		"booth_name=$booth_name", 
		"booth_no=$booth_no", 
		"no_email=$no_email" 
	);

	//Turn array into a delimited string using
	//the implode function
	$data = implode(" - ", $dataToLog);

	//Add a newline onto the end.
	$data .= PHP_EOL;

	//The name of your log file.
	//Modify this and add a full path if you want to log it in 
	//a specific directory.
	$pathToFile = 'postdata.log';

	//Log the data to your file using file_put_contents.
	file_put_contents($pathToFile, $data, FILE_APPEND);

}



// FUNCTIONS
// if any!



?>
</pre>
