<?php

	//env vars
	if (isset($_GET['testing'])){
		define('USE_TEST_SERVER', true);

		define('WEB_PATH', "kaws2025-drawing/viewer/"); // maps to /var/www/...
		define('STORAGE_PATH', "../files/imgs/");
		define('STORAGE_PATH_EMAIL',"../files/imgs-email/"); // store email image in a separate folder from imgs.
		define('WEB_IMG_PATH', "kaws2025-drawing/files/imgs/"); // maps to /var/www/...
		define('WEB_TMPL_IMG_PATH', "kaws2025-drawing/viewer/"); // maps to /var/www/html/templates...

	}else{
		define('USE_TEST_SERVER', false);

		define('WEB_PATH', "kaws2025-drawing/viewer/"); // maps to /var/www/...
		define('STORAGE_PATH', "../files/imgs/");
		define('STORAGE_PATH_EMAIL',"../files/imgs-email/"); // store email image in a separate folder from imgs.
		define('WEB_IMG_PATH', "kaws2025-drawing/files/imgs/"); // maps to /var/www/...
		define('WEB_TMPL_IMG_PATH', "kaws2025-drawing/viewer/"); // maps to /var/www/html/templates...

	}

	$barefilename = date('md-Gis') . "-" . uniqid();
	$log_content_id = $barefilename;
	$email_attachments = array();
	$imageUrl = array();

	$success = true;
	foreach($_FILES as $keyName=>$submitted) {
		if ($submitted['type'] == "image/jpeg" || preg_match("/\.jpe?g$/i", $submitted['name'])) {
			$attachment['type'] = 'jpg';
			// attach the actual file to the email
			//$email_attachments = array('type' => 'image/jpeg', 'tmp_name'=>$submitted['tmp_name'], 'filename'=>'kaws-drawing.jpg');
			$this_attachment = array('type' => 'image/jpeg', 'tmp_name'=>$submitted['tmp_name'], 'filename'=>'kaws-drawing.jpg');
			array_push($email_attachments, $this_attachment);

		}else if ($submitted['type'] == "image/gif" || preg_match("/\.gif$/i", $submitted['name'])) {
			$attachment['type'] = 'gif';

		}else if ($submitted['type'] == "image/png" || preg_match("/\.png$/i", $submitted['name'])) {
			$attachment['type'] = 'png';

		}else if (preg_match("/\.mp4$/i", $submitted['name'])) {
			$attachment['type'] = 'mp4';
			// attach the actual file to the email
			//$email_attachments = array('type' => 'video/mp4', 'tmp_name'=>$submitted['tmp_name'], 'filename'=>'kaws-drawing.mp4');
			$this_attachment = array('type' => 'video/mp4', 'tmp_name'=>$submitted['tmp_name'], 'filename'=>'kaws-drawing.mp4');
			array_push($email_attachments, $this_attachment);
		}

		$attachment['tmp_name'] = $submitted['tmp_name'];

		//plus keep the image
		$imagestored = STORAGE_PATH . $barefilename.'-'.$keyName.'.'.$attachment['type'];

		// set to false if there's a failure
		$success = $success && copy($submitted['tmp_name'],$imagestored);

		// Post-processing of .jpgs if required e.g. smaller version of .jpg for email-img
		if ($submitted['type'] == "image/jpeg" || preg_match("/\.jpe?g$/i", $submitted['name'])) {
			// resize and store a smaller version for email
			$emailimagestored = $barefilename.'-'.$keyName. '-email' . '.'.$attachment['type'];
			// ffmpeg not installed on smart?
			//system("ffmpeg -i $submitted['tmp_name'] -vf scale=500:-1 $emailimagestored");
			resizeImage($submitted, STORAGE_PATH_EMAIL , $emailimagestored, 500, 1000, 75); // need to pass (image object, save path, image name, max height, max width, quality)
		}

		//$imageUrl[$keyName] = //'http://' .$_SERVER["HTTP_HOST"] .'/'. WEB_IMG_PATH . 
		$imageUrl[$keyName] = //'https://' .$_SERVER["HTTP_HOST"] .'/'. WEB_IMG_PATH . 
							  $barefilename.'-'.$keyName.'.'.$attachment['type'];;
	}

	// web view link depends on specific booth unit (shopping centre)
	$magicviewurl = 'https://' .$_SERVER["HTTP_HOST"] .'/'. WEB_PATH .'?externalid=' . $barefilename;	
	//$magicviewurl = 'http://' .$_SERVER["HTTP_HOST"] .'/'. WEB_PATH .'?externalid=' . $barefilename;	
	
	// direct link to image
	$magicurl = 'https://' . $_SERVER["HTTP_HOST"] . '/' . WEB_IMG_PATH . $barefilename . '-image.jpg';
	//$magicurl = 'http://' . $_SERVER["HTTP_HOST"] . '/' . WEB_IMG_PATH . $barefilename . '-image.jpg';

	// link to email image
	$magicemailurl = 'https://' . $_SERVER["HTTP_HOST"] . '/' . preg_replace('/\/imgs\//','/imgs-email/',WEB_IMG_PATH) . $barefilename . '-img-email.jpg';
	//$magicemailurl = 'http://' . $_SERVER["HTTP_HOST"] . '/' . preg_replace('/\/imgs\//','/imgs-email/',WEB_IMG_PATH) . $barefilename . '-img-email.jpg';
		
	
	// set eim response header values...
	header("View-URL: $magicviewurl");	
	
function resizeImage($imgObject, $savePath, $imgName, $imgMaxWidth, $imgMaxHeight, $imgQuality)
	{
	    $source = imagecreatefromjpeg($imgObject['tmp_name']);
	    list($imgWidth, $imgHeight) = getimagesize($imgObject['tmp_name']);
	    $imgAspectRatio = $imgWidth / $imgHeight;
	    if ($imgMaxWidth / $imgMaxHeight > $imgAspectRatio)
	    {
	        $imgMaxWidth = intval(imgMaxHeight * $imgAspectRatio);
	    }
	    else
	    {
	        $imgMaxHeight = intval($imgMaxWidth / $imgAspectRatio);
	    }
	    $image_p = imagecreatetruecolor($imgMaxWidth, $imgMaxHeight);
	    $image = imagecreatefromjpeg($imgObject['tmp_name']);
	    imagecopyresampled($image_p, $source, 0, 0, 0, 0, $imgMaxWidth, $imgMaxHeight, $imgWidth, $imgHeight);
	    imagejpeg($image_p, $savePath . $imgName, $imgQuality);
	    unset($imgObject);
	    unset($source);
	    unset($image_p);
	    unset($image);
	}
