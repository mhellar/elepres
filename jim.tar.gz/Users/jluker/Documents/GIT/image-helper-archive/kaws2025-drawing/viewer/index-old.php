<?php
//print_r($_GET);

// XSS protection
// Quick and dirty sanitising of the id to: A-Z a-z 0-9 - _
$cleansedId = preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['externalid']);

?>
<!doctype html>
<html>

<head>

	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width">
	<title>KAWS: PLAYTIME | My Drawing</title>
	<link rel="stylesheet" type="text/css" href="css/normalize.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">


</head>

<body>
	<div class="wrapper">

		<div class="block" id="header">
			<a href="https://www.ngv.vic.gov.au/" rel="home">
				<img src="images/ngv_logo.svg" alt="National Gallery of Victoria" title="National Gallery of Victoria" />
			</a>
		</div>
		<div class="block" id="masthead">
			<img src="images/masthead.png" />
		</div>
		<div class="block" id="video">
			<video poster="/kaws2025-drawing/files/imgs/<?php echo $cleansedId; ?>-image.jpg" controls tabindex="0" preload="auto">
				<source type="video/mp4" src="/kaws2025-drawing/files/imgs/<?php echo $cleansedId; ?>-video.mp4">
			</video>
			<a href="/kaws2025-drawing/files/imgs/<?php echo $cleansedId; ?>-image.jpg" target="_blank" download><i class="far fa-file-image"></i> Download image <i class="fas fa-angle-right"></i></a>
			<a href="/kaws2025-drawing/files/imgs/<?php echo $cleansedId; ?>-video.mp4" target="_blank" download><i class="far fa-file-video"></i> Download video <i class="fas fa-angle-right"></i></a>
		</div>
		<div class="block" id="description">
			<p>Thank you for visiting <em>KAWS: PLAYTIME</em> at the National Gallery of Victoria. Brian Donnelly, aka KAWS, is one of the leading artists of his generation. His body of work includes murals, large-scale sculptures and public art.</p>
			<p><em>KAWS: PLAYTIME</em> is a free exhibition for kids and families, open daily until 13 April 2020.</p>
		</div>
		<div class="block" id="acknowledgment">
			<p><em>KAWS: PLAYTIME</em> is generously supported by The Truby and Florence Williams Charitable Trust, managed by Equity Trustees, The Fox Family Foundation, The Packer Family and Crown Resorts Foundations, The Neilson Foundation and Official Supplier, Canson Australia.</p>
		</div>
		<div class="block" id="footer">
			<div id="footer-inner">
				<div id="footer-left">
					<a href="http://creative.vic.gov.au/Home" target="_blank" rel="noopener noreferrer">
						<img src="images/creativevictoria_logo.svg" alt="Creative Victoria" title="Creative Victoria" />
					</a>
				</div>
				<div id="footer-right">
					<a href="http://www.twitter.com/ngvmelbourne" target="_blank" rel="noopener noreferrer"><span class="fa-stack fa-2x"><i class="fas fa-circle fa-stack-2x"></i><i class="fab fa-twitter fa-stack-1x fa-inverse"></i></span></a>
					<a href="http://www.facebook.com/ngvmelbourne" target="_blank" rel="noopener noreferrer"><span class="fa-stack fa-2x"><i class="fas fa-circle fa-stack-2x"></i><i class="fab fa-facebook-f fa-stack-1x fa-inverse"></i></span></a>
					<a href="http://www.instagram.com/ngvmelbourne" target="_blank" rel="noopener noreferrer"><span class="fa-stack fa-2x"><i class="fas fa-circle fa-stack-2x"></i><i class="fab fa-instagram fa-stack-1x fa-inverse"></i></span></a>
					<a href="https://www.ngv.vic.gov.au/lote/chinese/" target="_blank" rel="noopener noreferrer"><span class="fa-stack fa-2x"><i class="fas fa-circle fa-stack-2x"></i><i class="fab fa-weixin fa-stack-1x fa-inverse"></i></span></a>
				</div>
			</div>
		</div>

	</div>
</body>
</html>
