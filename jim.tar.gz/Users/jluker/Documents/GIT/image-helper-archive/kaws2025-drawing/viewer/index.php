<?php
//print_r($_GET);

// XSS protection
// Quick and dirty sanitising of the id to: A-Z a-z 0-9 - _
$cleansedId = preg_replace('/[^-a-zA-Z0-9_]/', '', $_GET['externalid']);

?>
<!doctype html>
<html>

<head>

	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width">
	<title>KAWS PLAYTIME | My Drawing</title>
	<link rel="stylesheet" type="text/css" href="css/normalize.min.css">
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.1/css/all.css" integrity="sha384-5sAR7xN1Nv6T6+dT2mhtzEpVJvfS3NScPQTrOxhwjIuvcA67KV2R5Jz6kr4abQsz" crossorigin="anonymous">

</head>

<body>
	<div class="wrapper">

		<div class="block" id="header">
		</div>
		<div class="block" id="masthead">
			<img src="images/masthead.png" />
		</div>
		<div class="block" id="video">
			<video poster="/kaws2025-drawing/files/imgs/<?php echo $cleansedId; ?>-image.jpg" controls tabindex="0" preload="auto">
				<source type="video/mp4" src="/kaws2025-drawing/files/imgs/<?php echo $cleansedId; ?>-video.mp4">
			</video>
			<a href="/kaws2025-drawing/files/imgs/<?php echo $cleansedId; ?>-image.jpg" target="_blank" download><i class="far fa-file-image"></i> Download image <i class="fas fa-angle-right"></i></a>
			<a href="/kaws2025-drawing/files/imgs/<?php echo $cleansedId; ?>-video.mp4" target="_blank" download><i class="far fa-file-video"></i> Download video <i class="fas fa-angle-right"></i></a>
		</div>
		<div class="block" id="description">
			<p></p>
		</div>
		<div class="block" id="acknowledgment">
			<p><em>KAWS PLAYTIME</em> was commissioned and developed by the NGV, Melbourne in collaboration with KAWS.</p>
		</div>
		<div class="block" id="footer">
			<div id="footer-inner">
				<div id="footer-left">
					<a href="https://www.ngv.vic.gov.au" target="_blank" rel="noopener noreferrer">
						<img src="images/NGV-Logo-ThirdParty.svg" alt="National Gallery of Victoria" title="National Gallery of Victoria" />
					</a>
				</div>
				<div id="footer-right">
				</div>
			</div>
		</div>

	</div>
</body>
</html>
